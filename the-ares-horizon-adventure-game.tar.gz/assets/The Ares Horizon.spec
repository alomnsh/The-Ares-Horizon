# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['The Ares Horizon.py'],
    pathex=[],
    binaries=[],
    datas=[('Click.mp3', '.'), ('Dream Sequence.mp3', '.'), ('Mission Failed.mp3', '.'), ('Mission Success.mp3', '.'), ('Pull Up.mp3', '.'), ('Roger That.mp3', '.'), ('Small Spike.png', '.'), ('Spacecraft Warning.mp3', '.'), ('Spaceship.png', '.'), ('Warning.mp3', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='The Ares Horizon',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
